# AplikasiTebaranNusira
Memberikan komentar bagi mereka yang menemukan sesuatu di lingkungan kerja yang menyebabkan pencemaran lingkungan

## Feature
- Tindakan Bahaya
- Kondisi Bahaya
- Pencemaran

## Library Used
* [Material Design](https://coil-kt.github.io/coil/) -> **Design**
* [iTextPDF](https://itextpdf.com/en/resources/api-documentation) -> **PDF**

## Developer
* [Candra Julius Sinaga](https://code.cjsflow.com/) -> **Programmer**

## Download App
* [Version 1.0](https://github.com/candrajulius/AplikasiTebaranNusira/releases/tag/1.0) -> **App Version**

