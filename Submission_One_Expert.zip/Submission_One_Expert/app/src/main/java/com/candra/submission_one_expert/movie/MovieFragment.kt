package com.candra.submission_one_expert.movie

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.candra.core.data.States
import com.candra.core.domain.model.Movie
import com.candra.core.ui.movieadapter.MovieAdapter
import com.candra.core.ui.movieadapter.RecomendedMovieAdapter
import com.candra.core.utils.Constant
import com.candra.core.utils.Helper.isDarkMode
import com.candra.submission_one_expert.R
import com.candra.submission_one_expert.databinding.MovieLayoutBinding
import com.candra.submission_one_expert.detail.DetailActivity
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class MovieFragment: Fragment()
{

    private val adapterMain by lazy { MovieAdapter(::onClick) }
    private val adapterRecomended by lazy { RecomendedMovieAdapter(::onClick) }
    private lateinit var layoutManager1: LinearLayoutManager

    private val movieViewModel by viewModels<MovieViewModel>()

    private var _binding: MovieLayoutBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = MovieLayoutBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        layoutManager1 = LinearLayoutManager(requireActivity(),LinearLayoutManager.HORIZONTAL,false)
        setAdapterAll(1)
        setAdapterAll(2)
        setAdapterAll(3)
        setComponentAll()
        observerAllData()
        binding.fabFavoriteMovie.setOnClickListener {
            toFavoriteDetail()
        }
    }

    private fun setComponentAll(){
        binding.apply {
            playingNowText.setTextColor(if (requireActivity().isDarkMode) ContextCompat.getColor(
                requireActivity(), R.color.white
            ) else ContextCompat.getColor(requireActivity(),R.color.black))
            trendingWeek.setTextColor(
                if (requireActivity().isDarkMode) ContextCompat.getColor(
                    requireActivity(),R.color.white
                )
            else ContextCompat.getColor(requireActivity(),R.color.black)
            )
            recomendedMovie.setTextColor(if(requireActivity().isDarkMode)
                ContextCompat.getColor(requireActivity(),R.color.white)
            else ContextCompat.getColor(requireActivity(),R.color.black))

            fabFavoriteShrinkAndExtend()
        }
    }

    private fun observerAllData(){
        movieViewModel.moviePlayingNow.observe(viewLifecycleOwner,this::setAllDataMoviePlayingNow)
        movieViewModel.movieTrendingDay.observe(viewLifecycleOwner,this::setTrendingDayMovie)
        movieViewModel.movieRecomended.observe(viewLifecycleOwner,this::setMovieRecomended)
    }

    fun onClick(movie: Movie){
        Intent(requireActivity(),DetailActivity::class.java).apply {
            putExtra(Constant.POSITION,1)
            putExtra(Constant.EXTRA_MOVIE,movie)
        }.also { startActivity(it) }
    }

    private fun setMovieRecomended(movieRecomended: States<List<Movie>>){
        when(movieRecomended){
            is States.Loading -> {
                showLoading(true,3)
            }
            is States.Success -> {
                showLoading(false,3)
                adapterRecomended.temptAllData(movieRecomended.data)
            }
            is States.Failed -> {
                failedFetchDataFromInternet(true)
                binding.tvError.text = movieRecomended.message ?: "Something wrong for application"
            }
        }
    }

    private fun setTrendingDayMovie(movieTrendingDay: States<List<Movie>>){
        when(movieTrendingDay){
            is States.Loading -> {
                showLoading(true,2)
            }
            is States.Success -> {
                showLoading(false,2)
                adapterMain.temptDataAll(movieTrendingDay.data)
            }
            is States.Failed -> {
                failedFetchDataFromInternet(true)
                binding.tvError.text = movieTrendingDay.message ?: "Something wrong for application"
            }
        }
    }

    private fun setAdapterAll(position: Int){
        when(position){
            1 -> {
                binding.rvPlayingNow.apply {
                    layoutManager = layoutManager1
                    adapter = adapterMain
                }
            }
            2 -> {
                binding.rvTrendingNowDays.apply {
                    layoutManager = LinearLayoutManager(requireActivity(),LinearLayoutManager.HORIZONTAL,false)
                    adapter = adapterMain
                }
            }
            3 -> {
                binding.rvRecomendedMovie.apply {
                    layoutManager = LinearLayoutManager(requireActivity(),LinearLayoutManager.VERTICAL,false)
                    adapter = adapterRecomended
                }
            }
        }
    }

    private fun toFavoriteDetail(){
        val uri = Uri.parse("submission_one_expert://favorite")
        startActivity(Intent(Intent.ACTION_VIEW,uri))
    }

    private fun setAllDataMoviePlayingNow(data: States<List<Movie>>){
        when(data){
            is States.Loading -> {
                showLoading(true,1)
            }
            is States.Success -> {
                showLoading(false,1)
                adapterMain.temptDataAll(data.data)
                Log.d("MovieFragment", "setMovieRecomended: ${data.data}")
            }
            is States.Failed -> {
                failedFetchDataFromInternet(true)
                binding.tvError.text = data.message ?: "Something wrong for application"
            }
        }
    }

    private fun failedFetchDataFromInternet(isVisibleError: Boolean){
        binding.apply {
            if (isVisibleError){
                tvError.visibility = View.VISIBLE
                progresBarNowPlaying.visibility = View.GONE
                progresBarTrendingDays.visibility = View.GONE
                progressBarRecomendedMovie.visibility = View.GONE
                rvPlayingNow.visibility = View.GONE
                rvRecomendedMovie.visibility = View.GONE
                rvTrendingNowDays.visibility = View.GONE
            }else{
                tvError.visibility = View.GONE
                progresBarNowPlaying.visibility = View.VISIBLE
                progresBarTrendingDays.visibility = View.VISIBLE
                progressBarRecomendedMovie.visibility = View.VISIBLE
                rvPlayingNow.visibility = View.VISIBLE
                rvRecomendedMovie.visibility = View.VISIBLE
                rvTrendingNowDays.visibility = View.VISIBLE
            }
        }
    }

    private fun showLoading(isLoading: Boolean,position: Int){
       binding.apply {
           when(position){
               1 -> {
                   progresBarNowPlaying.visibility = if (isLoading) View.VISIBLE else View.GONE
                   rvPlayingNow.visibility = if (isLoading) View.GONE else View.VISIBLE
               }
               2 -> {
                   progresBarTrendingDays.visibility = if (isLoading) View.VISIBLE else View.GONE
                   rvTrendingNowDays.visibility = if (isLoading) View.GONE else View.VISIBLE
               }
               3 -> {
                   progressBarRecomendedMovie.visibility = if (isLoading) View.VISIBLE else View.GONE
                   rvRecomendedMovie.visibility = if (isLoading) View.GONE else View.VISIBLE
               }
           }
       }
    }

    private fun fabFavoriteShrinkAndExtend(){
        binding.apply {
            nestedScroolView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener{_, _, scrollY, _, oldScrollY ->
                if (scrollY < oldScrollY){
                    fabFavoriteMovie.extend()
                }else{
                    fabFavoriteMovie.shrink()
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}

