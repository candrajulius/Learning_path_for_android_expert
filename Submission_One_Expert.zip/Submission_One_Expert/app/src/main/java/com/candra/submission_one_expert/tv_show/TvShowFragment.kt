package com.candra.submission_one_expert.tv_show

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.candra.core.data.States
import com.candra.core.domain.model.TvShow
import com.candra.core.ui.tvshowadapter.TvRecomendedAdapter
import com.candra.core.ui.tvshowadapter.TvShowAdapter
import com.candra.core.utils.Constant
import com.candra.core.utils.Helper.constLinearLayoutManager
import com.candra.core.utils.Helper.isDarkMode
import com.candra.submission_one_expert.R
import com.candra.submission_one_expert.databinding.MovieLayoutBinding
import com.candra.submission_one_expert.detail.DetailActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
@SuppressLint("SetTextI18n")
class TvShowFragment: Fragment()
{
    private var _binding:MovieLayoutBinding? = null
    private val tvShowAdapter by lazy { TvShowAdapter(::onClick) }
    private val tvRecomendedAdapter by lazy { TvRecomendedAdapter(::onClick) }
    private val tvShowViewModel by viewModels<TvViewModel>()

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = MovieLayoutBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observerAllData()
        setCompnentAll()
        setAdapterAll(1)
        setAdapterAll(2)
        setAdapterAll(3)
        binding.toolbarMovie.subtitle = getString(R.string.tv_show)
        fabFavoriteShrinkAndExtend()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun onClick(tvShow: TvShow) {
        Intent(requireActivity(),DetailActivity::class.java).apply {
            putExtra(Constant.POSITION,2)
            putExtra(Constant.EXTRA_TV,tvShow)
        }.also { startActivity(it) }
    }

    private fun observerAllData(){
        tvShowViewModel.tvPlayingNow.observe(viewLifecycleOwner,this::showPlayingTvShow)
        tvShowViewModel.tvTrendingWeek.observe(viewLifecycleOwner,this::showTrendingWeekTvShow)
        tvShowViewModel.tvRecomended.observe(viewLifecycleOwner,this::showTvShowRecomended)
    }

    private fun showTvShowRecomended(states: States<List<TvShow>>){
        when(states){
            is States.Loading -> showLoading(true,3)
            is States.Success -> {
                showLoading(false,3)
                tvRecomendedAdapter.temptAllDataTvShowRecomended(states.data)
            }
            is States.Failed -> {
                showLoading(false,3)
                failedFetchDataFromInternet(true)
            }
            else -> {
                showLoading(false,3)
                failedFetchDataFromInternet(isVisible)
                binding.tvError.text = "Application lost connection"
            }
        }
    }

    private fun showTrendingWeekTvShow(states: States<List<TvShow>>){
        when(states){
            is States.Loading -> showLoading(false,2)
            is States.Success -> {
                showLoading(false,2)
                tvShowAdapter.temptAllDataTvShow(states.data)
            }
            is States.Failed -> {
                showLoading(false,2)
                failedFetchDataFromInternet(true)
            }
            else -> {
                showLoading(false,2)
                failedFetchDataFromInternet(true)
                binding.tvError.text = "Application lost connection"
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showPlayingTvShow(state: States<List<TvShow>>){
        when(state){
            is States.Loading -> {
                showLoading(true,1)
            }
            is States.Success -> {
                tvShowAdapter.temptAllDataTvShow(state.data)
                showLoading(false,1)
            }
            is States.Failed -> {
                showLoading(false,1)
                failedFetchDataFromInternet(true)
            }
        }
    }

    private fun showLoading(isLoading: Boolean,position: Int){
        binding.apply {
            when(position){
                1 -> {
                    progresBarNowPlaying.visibility = if (isLoading) View.VISIBLE else View.GONE
                    rvPlayingNow.visibility = if (isLoading) View.GONE else View.VISIBLE
                }
                2 -> {
                    progresBarTrendingDays.visibility = if (isLoading) View.VISIBLE else View.GONE
                    rvTrendingNowDays.visibility = if (isLoading) View.GONE else View.VISIBLE
                }
                3 -> {
                    progressBarRecomendedMovie.visibility = if (isLoading) View.VISIBLE else View.GONE
                    rvRecomendedMovie.visibility = if (isLoading) View.GONE else View.VISIBLE
                }
            }
        }
    }

    private fun failedFetchDataFromInternet(isVisibleError: Boolean){
        binding.apply {
            if (isVisibleError){
                tvError.visibility = View.VISIBLE
                progresBarNowPlaying.visibility = View.GONE
                progresBarTrendingDays.visibility = View.GONE
                progressBarRecomendedMovie.visibility = View.GONE
                rvPlayingNow.visibility = View.GONE
                rvRecomendedMovie.visibility = View.GONE
                rvTrendingNowDays.visibility = View.GONE
            }else{
                tvError.visibility = View.GONE
                progresBarNowPlaying.visibility = View.VISIBLE
                progresBarTrendingDays.visibility = View.VISIBLE
                progressBarRecomendedMovie.visibility = View.VISIBLE
                rvPlayingNow.visibility = View.VISIBLE
                rvRecomendedMovie.visibility = View.VISIBLE
                rvTrendingNowDays.visibility = View.VISIBLE
            }
        }
    }

    private fun setCompnentAll(){
        binding.apply {
            playingNowText.setTextColor(if (requireActivity().isDarkMode) ContextCompat.getColor(
                requireActivity(), R.color.white
            ) else ContextCompat.getColor(requireActivity(), R.color.black))
            trendingWeek.setTextColor(
                if (requireActivity().isDarkMode) ContextCompat.getColor(
                    requireActivity(), R.color.white
                )
                else ContextCompat.getColor(requireActivity(), R.color.black)
            )
            recomendedMovie.setTextColor(if(requireActivity().isDarkMode)
                ContextCompat.getColor(requireActivity(), R.color.white)
            else ContextCompat.getColor(requireActivity(), R.color.black))
        }
    }

    private fun setAdapterAll(position: Int){
        when(position){
            1 -> {
                binding.rvPlayingNow.apply {
                    layoutManager = constLinearLayoutManager(requireActivity(),1)
                    adapter = tvShowAdapter
                }
            }
            2 -> {
                binding.rvTrendingNowDays.apply {
                    layoutManager = constLinearLayoutManager(requireActivity(),1)
                    adapter = tvShowAdapter
                }
            }
            3 -> {
                binding.rvRecomendedMovie.apply {
                    layoutManager = constLinearLayoutManager(requireActivity(),2)
                    adapter = tvRecomendedAdapter
                }
            }
        }
    }

    private fun toFavoriteTvShow(){
        val uri = Uri.parse("submission_one_expert://favorite")
        startActivity(Intent(Intent.ACTION_VIEW,uri))
    }

    private fun fabFavoriteShrinkAndExtend(){
        binding.apply {
            nestedScroolView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener{ _, _, scrollY, _, oldScrollY ->
                if (scrollY < oldScrollY){
                    fabFavoriteMovie.extend()
                }else{
                    fabFavoriteMovie.shrink()
                }
            })
            fabFavoriteMovie.setOnClickListener {
                toFavoriteTvShow()
            }
        }
    }

}