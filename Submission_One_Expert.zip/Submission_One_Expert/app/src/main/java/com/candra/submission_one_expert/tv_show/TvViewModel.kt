package com.candra.submission_one_expert.tv_show

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.candra.core.domain.usecase.MovieUseCase
import com.candra.core.utils.Constant
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TvViewModel @Inject constructor(
    private val movieUseCase: MovieUseCase
): ViewModel()
{
    val tvPlayingNow = movieUseCase.getTvShowPlayingNow(Constant.API_KEY).asLiveData()

    val tvRecomended = movieUseCase.getPopularNowTvShow(Constant.API_KEY).asLiveData()

    val tvTrendingWeek = movieUseCase.getTrendingTvShow(
        Constant.MEDIA_TYPE_TV,Constant.WEEK,Constant.API_KEY
    ).asLiveData()
}