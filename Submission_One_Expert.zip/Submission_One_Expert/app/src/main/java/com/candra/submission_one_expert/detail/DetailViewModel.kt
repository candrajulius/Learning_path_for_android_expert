package com.candra.submission_one_expert.detail

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.candra.core.domain.usecase.MovieUseCase
import com.candra.core.utils.Event
import com.candra.core.utils.FormatContent
import com.candra.core.utils.FormatContent.formatContentMovieRemove
import com.candra.core.utils.FormatContent.formatContentTvShowRemove
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val movieUseCase: MovieUseCase
): ViewModel()
{
    private var _isFavorite = MutableLiveData<Boolean>()
    val isFavorite get() = _isFavorite

    private val _snackbarText = MutableLiveData<Event<String>>()
    val snackBarText: LiveData<Event<String>> = _snackbarText

   fun insertMovieToFavorite(movie: Movie, title: String, context: Context) = viewModelScope.launch {
        movieUseCase.insertToFavoriteMovie(movie)
        _snackbarText.value = Event(FormatContent.formatContentMovieAdded(context,title))
   }

   fun insertTvShowToFavorite(tvShow: TvShow, context: Context, title: String) = viewModelScope.launch {
       movieUseCase.insertToFavoriteTvShow(tvShow)
       _snackbarText.value = Event(FormatContent.formatContentTvShowAdded(context,title))
   }

   fun removeMovieFromFavorite(movie: Movie, title: String, context: Context) = viewModelScope.launch {
       movieUseCase.deleteFavoriteMovie(movie)
       _snackbarText.value = Event(title.formatContentMovieRemove(context))
   }

    fun removeTvShowFromFavorite(tvShow: TvShow,title: String,context: Context) = viewModelScope.launch {
        movieUseCase.deleteFavoriteTvShow(tvShow)
        _snackbarText.value = Event(title.formatContentTvShowRemove(context))
    }

    fun isFavoriteFromFavorite(title: String) = viewModelScope.launch {
        movieUseCase.isFavorite(title).collect {
            _isFavorite.value = it
        }
    }
}