package com.candra.submission_one_expert.di

import com.candra.core.domain.usecase.MovieUseCase
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface FavoriteModuleDependecies{
    fun movieUsecase(): MovieUseCase
}