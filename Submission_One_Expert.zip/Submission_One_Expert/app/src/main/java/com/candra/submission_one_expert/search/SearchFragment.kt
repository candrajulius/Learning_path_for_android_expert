package com.candra.submission_one_expert.search

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.candra.core.data.States
import com.candra.core.domain.model.Movie
import com.candra.core.ui.movieadapter.RecomendedMovieAdapter
import com.candra.core.utils.Constant
import com.candra.core.utils.Helper.isDarkMode
import com.candra.submission_one_expert.R
import com.candra.submission_one_expert.databinding.SearchLayoutBinding
import com.candra.submission_one_expert.detail.DetailActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
@SuppressLint("SetTextI18n")
class SearchFragment: Fragment()
{
    private var _binding: SearchLayoutBinding? = null
    private val adapterSearch by lazy { RecomendedMovieAdapter(::onClick) }
    private val searchViewModel by viewModels<SearchViewModel>()

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = SearchLayoutBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        itConvertToStringEmpty()
        binding.edtSearch.addTextChangedListener {
            val itConvertToString = it.toString().trim()
            if (itConvertToString.isEmpty()){
                itConvertToStringEmpty()
            }
            else {
                searchMovie(itConvertToString)
            }
        }
        setAdapterSearch()
        binding.tvEmptyData.setTextColor(if (requireActivity().isDarkMode)
                ContextCompat.getColor(requireActivity(), R.color.white
                ) else ContextCompat.getColor(requireActivity(),R.color.black)
            )
    }

    private fun setAdapterSearch(){
        binding.rvSearch.apply {
            adapter = adapterSearch
            layoutManager = LinearLayoutManager(requireActivity(),LinearLayoutManager.VERTICAL,false)
        }
    }

    private fun itConvertToStringEmpty(){
        showTvEmptyList(true)
        binding.tvEmptyData.text = "Nothing data to show"
    }


    private fun searchMovie(query: String){
        searchViewModel.searchMovie(query).observe(viewLifecycleOwner){
            when(it){
                is States.Loading -> {
                    showLoading(true)
                    showTvEmptyList(false)
                }
                is States.Success -> {
                    showLoading(false)
                    adapterSearch.temptAllData(it.data)
                    showTvEmptyList(false)
                }
                is States.Failed -> {
                    showLoading(false)
                    showTvEmptyList(false)
                }
                is States.Empty -> {
                    showLoading(false)
                    binding.tvEmptyData.text = "Query is not found on the list"
                    showTvEmptyList(true)
                }
            }
        }
    }

    private fun showTvEmptyList(isShow: Boolean){
        binding.apply {
            tvEmptyData.visibility = if (isShow) View.VISIBLE else View.GONE
            progressBarSearch.visibility = if (isShow) View.GONE else View.VISIBLE
            rvSearch.visibility = if (isShow) View.GONE else View.VISIBLE
        }
    }

    private fun onClick(movie: Movie) {
        Intent(requireActivity(),DetailActivity::class.java).apply {
            putExtra(Constant.POSITION,1)
            putExtra(Constant.EXTRA_MOVIE,movie)
        }.also { startActivity(it) }
    }

    private fun showLoading(isShow: Boolean){
        binding.progressBarSearch.visibility = if (isShow) View.VISIBLE else View.GONE
        binding.rvSearch.visibility = if (isShow) View.GONE else View.VISIBLE
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}