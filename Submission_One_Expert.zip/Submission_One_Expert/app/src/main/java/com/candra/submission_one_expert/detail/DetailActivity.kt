package com.candra.submission_one_expert.detail

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.candra.core.utils.Constant
import com.candra.core.utils.Constant.EXTRA_MOVIE
import com.candra.core.utils.Constant.EXTRA_TV
import com.candra.core.utils.Constant.IMAGE_PATH
import com.candra.core.utils.Event
import com.candra.core.utils.FormatContent
import com.candra.core.utils.FormatContent.formatContentDetail
import com.candra.core.utils.Helper
import com.candra.core.utils.Helper.contentImage
import com.candra.submission_one_expert.databinding.ActivityDetailLayoutBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint

@SuppressLint("SetTextI18n")
@AndroidEntryPoint
class DetailActivity: AppCompatActivity(){

    private lateinit var binding: ActivityDetailLayoutBinding
    private val detailViewModel by viewModels<DetailViewModel>()
    private var isFavorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getDataFromActivity()
        binding.toolbarDetail.setNavigationOnClickListener {
            onBackPressed()
        }
        observerData()
    }

    private fun shareData(any: Any){
        when(any){
            is Movie -> {
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT,"Judul: ${any.title} \n Overview: ${any.overview} \n " +
                            "Release Date: ${any.releaseData}")
                }.also { startActivity(it) }
                finish()
            }
            is TvShow -> {
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT,"Judul: ${any.title} \n Overview: ${any.overview} \n " +
                            "Release Date: ${any.releaseDate}")
                }.also { startActivity(it) }
                finish()
            }
        }
    }

    private fun getDataFromActivity(){
        val position = intent.getIntExtra(Constant.POSITION,0)
        if (position == 1){
            showDetailMovie()
        }else if (position == 2){
            showDetailTvShow()
        }
    }

    private fun showDetailMovie(){
        intent.getParcelableExtra<Movie>(EXTRA_MOVIE)?.let { movie ->
            with(binding){
                tvName.text = movie.title
                tvRating.text = "${movie.voteAverage} /10"
                tvPopularity.text = movie.popularity.toString()
                tvOverview.text = movie.overview
                tvName.isSelected = true
                tvRelease.text = FormatContent.parsingDateFormat(movie.releaseData)

                val newValue = movie.voteAverage.toFloat()
                ratingBar.apply {
                    numStars = 5
                    stepSize = 0.5f
                    rating = newValue / 2
                }
                imgPhoto.contentImage(IMAGE_PATH + movie.thumbnail)
                imgCover.contentImage(IMAGE_PATH + movie.thumbnail)
                toolbarDetail.subtitle = movie.title.formatContentDetail(
                    this@DetailActivity,1
                )

                fabShare.setOnClickListener {
                    shareData(movie)
                }

                detailViewModel.isFavoriteFromFavorite(movie.title)

                fabFavorite.setOnClickListener {
                    if (isFavorite) detailViewModel.removeMovieFromFavorite(movie,movie.title,this@DetailActivity)
                    else detailViewModel.insertMovieToFavorite(movie,movie.title,this@DetailActivity)
                }
            }
        }
    }

    private fun observerData(){
        detailViewModel.isFavorite.observe(this@DetailActivity){
            isFavorite = it
            binding.fabFavorite.setFavorite(it,this@DetailActivity)
        }
        detailViewModel.snackBarText.observe(this@DetailActivity,this::showSnackBar)
    }

    private fun showSnackBar(eventMessage: Event<String>){
        val message = eventMessage.getContentIfNotHandled() ?: return
        Snackbar.make(
            binding.containerLayoutDetail,
            message,
            Snackbar.LENGTH_SHORT
        ).show()
    }

    private fun showDetailTvShow(){
        intent.getParcelableExtra<TvShow>(EXTRA_TV)?.let { tvShow ->
            with(binding){
                    tvName.text = tvShow.title
                    tvRating.text = "${tvShow.voteAverage} /10"
                    tvPopularity.text = tvShow.popularity.toString()
                    tvOverview.text = tvShow.overview
                    tvRelease.text = FormatContent.parsingDateFormat(tvShow.releaseDate)
                    ratingBar.apply {
                        numStars = 5
                        stepSize = 0.5f
                        rating = tvShow.voteAverage.toFloat() / 2
                    }
                    imgPhoto.contentImage(IMAGE_PATH + tvShow.thumbnail)
                    imgCover.contentImage(IMAGE_PATH + tvShow.cover)
                    toolbarDetail.subtitle = tvShow.title.formatContentDetail(
                        this@DetailActivity,2
                    )

                    detailViewModel.isFavoriteFromFavorite(tvShow.title)

                    fabShare.setOnClickListener {
                        shareData(tvShow)
                    }

                    fabFavorite.setOnClickListener {
                        if (isFavorite) detailViewModel.removeTvShowFromFavorite(tvShow,tvShow.title,this@DetailActivity)
                        else detailViewModel.insertTvShowToFavorite(tvShow,this@DetailActivity,tvShow.title)
                    }
            }
        }
    }

    private fun FloatingActionButton.setFavorite(isStatusFavorite: Boolean, context: Context){
        if (isStatusFavorite){
            this.setImageDrawable(ContextCompat.getDrawable(context, com.candra.submission_one_expert.R.drawable.ic_baseline_favorite_24))
        }else{
            this.setImageDrawable(ContextCompat.getDrawable(context, com.candra.submission_one_expert.R.drawable.ic_baseline_favorite_border_24))
        }
    }

}