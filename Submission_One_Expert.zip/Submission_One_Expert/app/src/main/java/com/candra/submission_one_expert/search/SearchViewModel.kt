package com.candra.submission_one_expert.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.candra.core.domain.usecase.MovieUseCase
import com.candra.core.utils.Constant
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val movieUseCase: MovieUseCase
): ViewModel()
{
    fun searchMovie(query: String) = movieUseCase.searchMovie(Constant.API_KEY,query).asLiveData()

}