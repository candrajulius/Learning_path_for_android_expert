package com.candra.submission_one_expert.movie

import androidx.lifecycle.*
import com.candra.core.domain.usecase.MovieUseCase
import com.candra.core.utils.Constant.API_KEY
import com.candra.core.utils.Constant.MEDIA_TYPE_MOVIE
import com.candra.core.utils.Constant.WEEK
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MovieViewModel @Inject constructor(
    private val movieUseCase: MovieUseCase
): ViewModel() {

    val moviePlayingNow = movieUseCase.getNowPlayingMovie(API_KEY).asLiveData()

    val movieTrendingDay = movieUseCase.getTrendingMovieAndTvShow(MEDIA_TYPE_MOVIE, WEEK, API_KEY).asLiveData()

    val movieRecomended = movieUseCase.getPopularNowMovie(API_KEY).asLiveData()

}