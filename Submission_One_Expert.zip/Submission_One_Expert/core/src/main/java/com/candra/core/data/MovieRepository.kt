package com.candra.core.data


import com.candra.core.data.source.local.LocalDataSource
import com.candra.core.data.source.remote.RemoteDataSource
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.candra.core.domain.repository.IRepository
import com.candra.core.utils.Helper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject


class MovieRepository @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    private val localDataSource: LocalDataSource
): IRepository {
    override  fun getNowPlayingMovie(apiKey: String): Flow<States<List<Movie>>> =
        remoteDataSource.getPlayingNow(apiKey)

    override  fun getTvShowPlayingNow(apiKey: String): Flow<States<List<TvShow>>> =
        remoteDataSource.getTvShowPlayingNow(apiKey)

    override fun getTrendingMovieAndTvShow(
        mediaType: String,
        timeWindow: String,
        apiKey: String
    ): Flow<States<List<Movie>>> =
        remoteDataSource.getTrendingMovieAndTvShow(mediaType,timeWindow,apiKey)

    override  fun getPopularMovie(apiKey: String): Flow<States<List<Movie>>> =
        remoteDataSource.getPopularMovie(apiKey)

    override fun getTrendingTvShow(
        mediaType: String,
        timeWindow: String,
        apiKey: String
    ): Flow<States<List<TvShow>>> =
        remoteDataSource.getTrendingTvShow(mediaType,timeWindow,apiKey)


    override  fun getPopularTvShow(apiKey: String): Flow<States<List<TvShow>>> =
        remoteDataSource.getPopularTvShow(apiKey)

    override  fun searchMovie(apiKey: String, query: String): Flow<States<List<Movie>>> =
        remoteDataSource.searchMovie(apiKey,query)

    override fun getFavoriteMovie(): Flow<List<Movie>> =
        localDataSource.getAllFavoriteAny().map {
            Helper.mapEntitiesToDomainMovie(it)
        }

    override fun getFavoriteTvShow(): Flow<List<TvShow>>  =
        localDataSource.getAllFavoriteAny().map {
            Helper.mapEntitiesToDomainTvShow(it)
        }

    override suspend fun insertToFavoriteMovie(movie: Movie) {
        localDataSource.insertToFavoriteEntity(
            Helper.mapDomainToEntityMovie(movie)
        )
    }

    override suspend fun insertToFavoriteTvShow(tvShow: TvShow) {
        localDataSource.insertToFavoriteEntity(
            Helper.mapDomainToEntityTvShow(tvShow)
        )
    }


    override suspend fun deleteFromFavoriteMovie(movie: Movie) {
        localDataSource.deleteFromFavorite(
            Helper.mapDomainToEntityMovie(movie)
        )
    }

    override suspend fun deleteFromFavoriteTVShow(tvShow: TvShow) {
        localDataSource.deleteFromFavorite(
            Helper.mapDomainToEntityTvShow(tvShow)
        )
    }

    override fun isFavorite(title: String): Flow<Boolean> =
        localDataSource.isFavorite(title)

}