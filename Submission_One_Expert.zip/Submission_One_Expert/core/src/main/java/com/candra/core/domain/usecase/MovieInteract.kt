package com.candra.core.domain.usecase

import com.candra.core.data.States
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.candra.core.domain.repository.IRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class MovieInteract @Inject constructor(
    private val movieIRepository: IRepository
): MovieUseCase {
    // Network
    override  fun getNowPlayingMovie(apiKey: String): Flow<States<List<Movie>>> =
        movieIRepository.getNowPlayingMovie(apiKey)

    override  fun getTvShowPlayingNow(apiKey: String): Flow<States<List<TvShow>>> =
        movieIRepository.getTvShowPlayingNow(apiKey)

    override  fun getTrendingMovieAndTvShow(
        mediaType: String,
        timeWindow: String,
        apiKey: String
    ): Flow<States<List<Movie>>> =
        movieIRepository.getTrendingMovieAndTvShow(mediaType, timeWindow, apiKey)

    override fun getTrendingTvShow(
        mediaType: String,
        timeWindow: String,
        apiKey: String
    ): Flow<States<List<TvShow>>> =
        movieIRepository.getTrendingTvShow(mediaType,timeWindow,apiKey)

    override  fun getPopularNowMovie(apiKey: String): Flow<States<List<Movie>>> =
        movieIRepository.getPopularMovie(apiKey)

    override  fun getPopularNowTvShow(apiKey: String): Flow<States<List<TvShow>>> =
        movieIRepository.getPopularTvShow(apiKey)

    override  fun searchMovie(apiKey: String, query: String): Flow<States<List<Movie>>> =
        movieIRepository.searchMovie(apiKey, query)


    // Database
    override fun getAllFavoriteMovie(): Flow<List<Movie>> =
        movieIRepository.getFavoriteMovie()


    override fun getAllFavoriteTvShow(): Flow<List<TvShow>> =
        movieIRepository.getFavoriteTvShow()


    override suspend fun insertToFavoriteMovie(movie: Movie) =
        movieIRepository.insertToFavoriteMovie(movie)


    override suspend fun insertToFavoriteTvShow(tvShow: TvShow) =
        movieIRepository.insertToFavoriteTvShow(tvShow)

    override suspend fun deleteFavoriteMovie(movie: Movie) =
        movieIRepository.deleteFromFavoriteMovie(movie)

    override suspend fun deleteFavoriteTvShow(tvShow: TvShow) =
        movieIRepository.deleteFromFavoriteTVShow(tvShow)

    override fun isFavorite(title: String): Flow<Boolean> =
        movieIRepository.isFavorite(title)



}