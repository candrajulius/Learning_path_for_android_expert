package com.candra.core.data.source.remote

import android.util.Log
import com.candra.core.data.States
import com.candra.core.data.source.remote.network.ApiService
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.candra.core.domain.model.toGenerateListMovie
import com.candra.core.domain.model.toGenerateTvShow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class RemoteDataSource @Inject constructor(private val apiService: ApiService){
    companion object{
        const val TAG = "RemoteDataSource"
    }
    fun getPlayingNow(apiKey: String) = flow<States<List<Movie>>> {
       emit(States.loading())
       val dataService =  apiService.getNowPlayingMovie(apiKey)
       dataService.let{
           if (it.isSuccessful && it.body() != null) {
               emit(States.success(it.body()?.results?.toGenerateListMovie() ?: listOf()))
           } else {
               emit(States.failed(it.message().toString()))
           }
       }
    }.catch {
        Log.d(TAG, "getPlayingNow: ${it.message}")
        emit(States.failed(it.message.toString()))
    }.flowOn(Dispatchers.IO)

    fun getTvShowPlayingNow(apiKey: String) = flow<States<List<TvShow>>> {
        emit(States.loading())
        apiService.getTvShowPlayingNow(apiKey).let {
            if (it.isSuccessful && it.body() != null) emit(States.success(it.body()?.resultTvShows?.toGenerateTvShow()?: listOf()))
            else emit(States.failed(it.message().toString()))
        }
    }.catch {
        Log.d(TAG, "getTvShowPlayingNow: ${it.message.toString()}")
    }.flowOn(Dispatchers.IO)

    fun getPopularMovie(apiKey: String) = flow<States<List<Movie>>> {
        emit(States.loading())
        apiService.getPopularMovie(apiKey).let {
            if (it.isSuccessful && it.body() != null) emit(States.success(it.body()?.results?.toGenerateListMovie()?: listOf()))
            else emit(States.failed(it.message().toString()))
        }
    }.catch {
        Log.d(TAG, "getPopularMovie: ${it.message.toString()}")
        emit(States.failed(it.message.toString()))
    }.flowOn(Dispatchers.IO)

    fun getPopularTvShow(apiKey: String) = flow<States<List<TvShow>>> {
        emit(States.loading())
        apiService.getPopularTvShow(apiKey).let {
            if (it.isSuccessful && it.body() != null) emit(States.success(it.body()?.resultTvShows?.toGenerateTvShow()?: listOf()))
            else emit(States.failed(it.message().toString()))
        }
    }.catch {
        Log.d(TAG, "getPopularTvShow: ${it.message.toString()}")
        emit(States.failed(it.message.toString()))
    }.flowOn(Dispatchers.IO)

    fun getTrendingMovieAndTvShow(mediaType: String,timeWindow: String,apiKey: String)
     = flow<States<List<Movie>>> {
         emit(States.loading())
        apiService.getTrendingMovieAndTvShow(mediaType,timeWindow,apiKey).let {
            if (it.isSuccessful && it.body() != null) emit(States.success(it.body()?.results?.toGenerateListMovie()?: listOf()))
            else emit(States.failed(it.message().toString()))
        }
    }.catch {
        Log.d(TAG, "getTrendingMovieAndTvShow: ${it.message.toString()}")
        emit(States.failed(it.message.toString()))
    }.flowOn(Dispatchers.IO)

    fun getTrendingTvShow(mediaType: String,timeWindow: String,apiKey: String) =
        flow<States<List<TvShow>>> {
            emit(States.loading())
            apiService.getTrendingTvShow(mediaType,timeWindow,apiKey).let {
                if (it.isSuccessful && it.body() != null){
                    emit(States.success(it.body()?.resultTvShows?.toGenerateTvShow()?: listOf()))
                }else{
                    emit(States.failed(it.message().toString()))
                }
            }
        }.catch {
            Log.d(TAG, "getTrendingTvShow: ${it.message.toString()}")
            emit(States.failed(it.message.toString()))
        }.flowOn(Dispatchers.IO)

    fun searchMovie(apiKey: String,query: String) = flow<States<List<Movie>>> {
        emit(States.loading())
        apiService.searchMovie(apiKey = apiKey,query = query).let {
            if (it.isSuccessful && it.body() != null){
                val movieData = it.body()?.results?.toGenerateListMovie()
                if (movieData?.isEmpty() == true){
                    emit(States.empty())
                }else{
                    emit(States.success(movieData?: listOf()))
                }
            }else{
                emit(States.failed(it.message().toString()))
            }
        }
    }.catch {
        Log.d(TAG, "searchMovie: ${it.message.toString()}")
        emit(States.failed(it.message.toString()))
    }.flowOn(Dispatchers.IO)
}