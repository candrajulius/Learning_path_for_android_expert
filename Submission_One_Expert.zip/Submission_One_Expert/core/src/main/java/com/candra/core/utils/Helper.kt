package com.candra.core.utils

import android.content.Context
import android.content.res.Configuration.UI_MODE_NIGHT_MASK
import android.content.res.Configuration.UI_MODE_NIGHT_YES
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.candra.core.R
import com.candra.core.data.source.local.entity.ModelEntity
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.google.android.material.floatingactionbutton.FloatingActionButton

object Helper {



    fun mapEntitiesToDomainMovie(input: List<ModelEntity>):List<Movie> {
       return input.map {
            Movie(
                id = it.id,
                title = it.title,
                voteAverage = it.voteAverage,
                releaseData = it.releaseData,
                popularity = it.popularity,
                overview = it.overview,
                thumbnail = it.thumbnail,
                cover = it.cover,
                isFavorite = it.isFavorite
            )
        }
    }

    fun mapDomainToEntityMovie(input: Movie) = ModelEntity(
        id = input.id,
        title = input.title,
        voteAverage = input.voteAverage,
        releaseData = input.releaseData,
        popularity = input.popularity,
        overview = input.overview,
        cover = input.cover,
        thumbnail = input.thumbnail,
        isFavorite = input.isFavorite
    )

    fun mapEntitiesToDomainTvShow(input: List<ModelEntity>): List<TvShow>{
        return input.map {
            TvShow(
                id = it.id,
                title = it.title,
                voteAverage = it.voteAverage,
                releaseDate = it.releaseData,
                popularity = it.popularity,
                overview = it.overview,
                thumbnail = it.thumbnail,
                cover = it.cover,
                isFavorite = it.isFavorite
            )
        }
    }

    fun mapDomainToEntityTvShow(input: TvShow) = ModelEntity(
        id = input.id,
        title = input.title,
        voteAverage = input.voteAverage,
        releaseData = input.releaseDate,
        popularity = input.popularity,
        overview = input.overview,
        cover = input.cover,
        thumbnail = input.thumbnail,
        isFavorite = input.isFavorite
    )

    val Context.isDarkMode get() = this.resources?.configuration?.uiMode?.and(UI_MODE_NIGHT_MASK) == UI_MODE_NIGHT_YES

    fun constLinearLayoutManager(context: Context,position: Int): LinearLayoutManager? {
        var layoutManager: LinearLayoutManager? = null
        when(position){
            1  -> {
               layoutManager =  LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
            }
            2 -> {
                layoutManager = LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false)
            }
        }
        return layoutManager
    }

    fun ImageView.contentImage(url: String){
        this.load(url){
            crossfade(600)
            crossfade(true)
            error(R.drawable.ic_baseline_broken_image_24)
            placeholder(R.drawable.ic_baseline_image_24)
        }
    }


}
