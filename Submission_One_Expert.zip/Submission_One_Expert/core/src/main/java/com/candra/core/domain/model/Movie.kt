package com.candra.core.domain.model

import android.os.Parcelable
import com.candra.core.data.source.remote.response.movieresponse.ResultMovie
import kotlinx.parcelize.Parcelize

@Parcelize
data class Movie(
    val id: Int,
    val title: String,
    val voteAverage: Double,
    val releaseData: String,
    val popularity: Double,
    val overview: String,
    val thumbnail: String,
    val cover: String,
    val isFavorite: Boolean
): Parcelable

fun List<ResultMovie>.toGenerateListMovie(): MutableList<Movie>{
    val listResponseMovie = mutableListOf<Movie>()
    this.forEach { listResponseMovie.add(it.toMovie()) }
    return listResponseMovie
}

fun ResultMovie.toMovie(): Movie = Movie(
    id = this.id,
    title = this.title,
    voteAverage = this.voteAverage,
    releaseData = this.releaseDate,
    popularity = this.popularity,
    overview = this.overview,
    thumbnail = this.posterPath,
    cover = this.backdropPath,
    isFavorite = false
)