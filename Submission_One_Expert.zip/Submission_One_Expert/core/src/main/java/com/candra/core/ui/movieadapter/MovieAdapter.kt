package com.candra.core.ui.movieadapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.candra.core.R
import com.candra.core.databinding.ListItemHorizontalBinding
import com.candra.core.domain.model.Movie
import com.candra.core.utils.Constant

class MovieAdapter(
   private val onClick: (Movie) -> Unit
): RecyclerView.Adapter<MovieAdapter.ViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ListItemHorizontalBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(differ.currentList[position])
    }

    override fun getItemCount(): Int  = differ.currentList.size

   inner class ViewHolder(private val binding: ListItemHorizontalBinding): RecyclerView.ViewHolder(binding.root)
    {
        fun bind(data: Movie){
            with(binding){
                imagePhoto.load(Constant.IMAGE_PATH2 + data.thumbnail){
                    crossfade(true)
                    crossfade(600)
                    error(R.drawable.ic_baseline_broken_image_24)
                    placeholder(R.drawable.ic_baseline_image_24)
                }
                itemView.setOnClickListener {
                    onClick(data)
                }
            }
        }
    }

    private val differ = AsyncListDiffer(this,object: DiffUtil.ItemCallback<Movie>(){
        override fun areItemsTheSame(oldItem: Movie, newItem: Movie): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Movie, newItem: Movie): Boolean {
           return oldItem == newItem
        }

    })

    fun temptDataAll(listData: List<Movie>){
        differ.submitList(listData)
    }

}