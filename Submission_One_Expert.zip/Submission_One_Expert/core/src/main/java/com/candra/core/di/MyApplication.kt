package com.candra.core.di

import android.app.Application
import dagger.Module
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyApplication: Application()
