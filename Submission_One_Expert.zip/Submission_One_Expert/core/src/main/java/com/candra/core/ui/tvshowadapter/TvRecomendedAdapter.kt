package com.candra.core.ui.tvshowadapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.candra.core.R
import com.candra.core.databinding.ListItemRecomendedBinding
import com.candra.core.domain.model.TvShow
import com.candra.core.utils.Constant
import com.candra.core.utils.FormatContent.parsingDateFormat
import com.candra.core.utils.Helper.isDarkMode

class TvRecomendedAdapter(
    private val onClickTvRecomended: (TvShow) -> Unit
): RecyclerView.Adapter<TvRecomendedAdapter.ViewHolder>()
{

    inner class ViewHolder(private val binding: ListItemRecomendedBinding):
        RecyclerView.ViewHolder(binding.root){
            fun bind(dataShowTv: TvShow){
                with(binding){
                    tvTitle.text = dataShowTv.title
                    tvReleaseDate.text = parsingDateFormat(dataShowTv.releaseDate)
                    tvDesc.text = dataShowTv.overview
                    val newValueRating = dataShowTv.voteAverage.toFloat()
                    imgPhoto.load(Constant.IMAGE_PATH2 + dataShowTv.thumbnail){
                        crossfade(600)
                        crossfade(true)
                        error(R.drawable.ic_baseline_broken_image_24)
                        placeholder(R.drawable.ic_baseline_image_24)
                    }

                    ratingBar.apply {
                        numStars = 5
                        stepSize = 0.5F
                        rating = newValueRating / 2
                    }
                    rootFrameLayout.setOnClickListener {
                        onClickTvRecomended(dataShowTv)
                    }
                    tvTitle.setTextColor(if (itemView.context.isDarkMode) ContextCompat.getColor(itemView.context,
                        R.color.black)
                    else ContextCompat.getColor(itemView.context, R.color.black))
                    tvDesc.setTextColor(if (itemView.context.isDarkMode) ContextCompat.getColor(itemView.context,
                        R.color.black)
                    else ContextCompat.getColor(itemView.context, R.color.black))
                }
            }
        }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TvRecomendedAdapter.ViewHolder {
        return ViewHolder(
            ListItemRecomendedBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        )
    }

    override fun onBindViewHolder(holder: TvRecomendedAdapter.ViewHolder, position: Int) {
        holder.bind(differ.currentList[position])
    }

    override fun getItemCount(): Int = differ.currentList.size

    private val differ = AsyncListDiffer(this,object: DiffUtil.ItemCallback<TvShow>(){
        override fun areItemsTheSame(oldItem: TvShow, newItem: TvShow): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: TvShow, newItem: TvShow): Boolean {
            return oldItem == newItem
        }
    })

    fun temptAllDataTvShowRecomended(listItem: List<TvShow>){
        differ.submitList(listItem)
    }

}