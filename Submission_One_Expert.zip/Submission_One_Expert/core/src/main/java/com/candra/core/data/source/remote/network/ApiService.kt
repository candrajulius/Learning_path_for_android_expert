package com.candra.core.data.source.remote.network

import com.candra.core.data.source.remote.response.movieresponse.MovieResponse
import com.candra.core.data.source.remote.response.tv_show_response.TvShowResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService{

    // Untuk playing skrng
    @GET("movie/now_playing")
    suspend fun getNowPlayingMovie(
        @Query("api_key") apiKey: String
    ): Response<MovieResponse>

    // Untuk yang airing_today tv
    @GET("tv/airing_today")
    suspend fun getTvShowPlayingNow(
        @Query("api_key") apiKey: String,
        @Query("language") languages: String = "en-US",
        @Query("page") page: Int = 1
    ): Response<TvShowResponse>

    // Untuk trending movie
    @GET("trending/{media_type}/{time_window}")
    suspend fun getTrendingMovieAndTvShow(
        @Path("media_type") mediaType: String,
        @Path("time_window") timeWindow: String,
        @Query("api_key") apiKey: String
    ): Response<MovieResponse>

    @GET("trending/{media_type}/{time_window}")
    suspend fun getTrendingTvShow(
        @Path("media_type") mediaType: String,
        @Path("time_window") timeWindow: String,
        @Query("api_key") apiKey: String
    ): Response<TvShowResponse>

    // Untuk Movie Populer
    @GET("movie/popular")
    suspend fun getPopularMovie(
        @Query("api_key") apiKey: String
    ): Response<MovieResponse>

    // Untuk TV Populer
    @GET("tv/popular")
    suspend fun getPopularTvShow(
        @Query("api_key") apiKey: String
    ): Response<TvShowResponse>

    // Untuk Search
    @GET("search/movie")
    suspend fun searchMovie(
        @Query("api_key") apiKey: String,
        @Query("language") languages: String = "en-US",
        @Query("query") query: String,
        @Query("page") page: Int = 1,
        @Query("include_adult") include_adult: Boolean = false
    ): Response<MovieResponse>
}