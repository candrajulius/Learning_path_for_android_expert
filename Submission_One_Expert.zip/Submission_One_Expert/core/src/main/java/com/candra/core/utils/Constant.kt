package com.candra.core.utils

import com.candra.core.R
import com.google.gson.GsonBuilder

object Constant {
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val IMAGE_PATH = "https://image.tmdb.org/t/p/w780"
    const val IMAGE_PATH2 = "https://image.tmdb.org/t/p/w500"
    const val API_KEY = "863275593dd14b7b2035255c29ca5bd4"
    const val EXTRA_TV = "extra_movie"
    const val WEEK = "week"
    const val MEDIA_TYPE_MOVIE = "movie"
    const val POSITION = "position"
    const val EXTRA_MOVIE = "extra_movie"
    const val MEDIA_TYPE_TV = "tv"

}