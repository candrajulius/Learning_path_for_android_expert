package com.candra.core.domain.usecase


import com.candra.core.data.States
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import kotlinx.coroutines.flow.Flow

interface MovieUseCase{
    fun getNowPlayingMovie(apiKey: String): Flow<States<List<Movie>>>

    fun getTvShowPlayingNow(apiKey: String): Flow<States<List<TvShow>>>

    fun getTrendingMovieAndTvShow(mediaType: String,timeWindow: String,apiKey: String)
    : Flow<States<List<Movie>>>

    fun getTrendingTvShow(mediaType: String,timeWindow: String,apiKey: String)
    : Flow<States<List<TvShow>>>

    fun getPopularNowMovie(apiKey: String): Flow<States<List<Movie>>>

    fun getPopularNowTvShow(apiKey: String): Flow<States<List<TvShow>>>

    fun searchMovie(apiKey: String,query: String): Flow<States<List<Movie>>>

   fun getAllFavoriteMovie(): Flow<List<Movie>>

   fun getAllFavoriteTvShow(): Flow<List<TvShow>>

   suspend fun insertToFavoriteMovie(movie: Movie)

   suspend fun insertToFavoriteTvShow(tvShow: TvShow)

  suspend fun deleteFavoriteMovie(movie: Movie)

  suspend fun deleteFavoriteTvShow(tvShow: TvShow)

   fun isFavorite(title: String): Flow<Boolean>

}