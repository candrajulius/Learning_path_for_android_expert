package com.candra.core.domain.repository

import com.candra.core.data.States
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import kotlinx.coroutines.flow.Flow


interface IRepository {

   fun getNowPlayingMovie(apiKey: String,): Flow<States<List<Movie>>>

   fun getTvShowPlayingNow(apiKey: String): Flow<States<List<TvShow>>>

   fun getTrendingMovieAndTvShow(mediaType: String,timeWindow: String,apiKey: String):
           Flow<States<List<Movie>>>

   fun getPopularMovie(apiKey: String): Flow<States<List<Movie>>>

   fun getTrendingTvShow(mediaType: String,timeWindow: String,apiKey: String)
   : Flow<States<List<TvShow>>>

   fun getPopularTvShow(apiKey: String): Flow<States<List<TvShow>>>

   fun searchMovie(apiKey: String,query: String): Flow<States<List<Movie>>>

   fun getFavoriteMovie(): Flow<List<Movie>>

   fun getFavoriteTvShow(): Flow<List<TvShow>>

  suspend fun insertToFavoriteMovie(movie: Movie)

  suspend fun insertToFavoriteTvShow(tvShow: TvShow)

 suspend fun deleteFromFavoriteMovie(movie: Movie)

 suspend fun deleteFromFavoriteTVShow(tvShow: TvShow)

  fun isFavorite(title: String): Flow<Boolean>
   
}