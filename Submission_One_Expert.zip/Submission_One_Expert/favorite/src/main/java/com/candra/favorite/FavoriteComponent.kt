package com.candra.favorite

import android.content.Context
import com.candra.submission_one_expert.di.FavoriteModuleDependecies
import dagger.BindsInstance
import dagger.Component

@Component(dependencies = [FavoriteModuleDependecies::class])
interface FavoriteComponent{

    fun inject(activity: FavoriteActivity)

    @Component.Builder
    interface Builder{
        fun context(@BindsInstance context: Context): Builder
        fun appDependencies(favoriteModuleDepencies: FavoriteModuleDependecies): Builder
        fun build(): FavoriteComponent
    }
}