package com.candra.favorite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.candra.core.domain.model.Movie
import com.candra.core.domain.model.TvShow
import com.candra.core.ui.movieadapter.RecomendedMovieAdapter
import com.candra.core.ui.tvshowadapter.TvRecomendedAdapter
import com.candra.core.utils.Constant.EXTRA_MOVIE
import com.candra.core.utils.Constant.EXTRA_TV
import com.candra.core.utils.Constant.POSITION
import com.candra.core.utils.Helper
import com.candra.core.utils.Helper.isDarkMode
import com.candra.favorite.databinding.ActivityFavoriteBinding
import com.candra.submission_one_expert.detail.DetailActivity
import com.candra.submission_one_expert.di.FavoriteModuleDependecies
import dagger.hilt.android.EntryPointAccessors
import javax.inject.Inject

class FavoriteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoriteBinding

    @Inject
    lateinit var factory: ViewModelFactory

    private val movieAdapter by lazy { RecomendedMovieAdapter(::onClickMovie) }
    private val tvShowAdapter by lazy { TvRecomendedAdapter(::onClickTvShow) }


    private val favoriteViewModel: FavoriteViewModel by viewModels {
        factory
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        DaggerFavoriteComponent.builder()
            .context(this)
            .appDependencies(EntryPointAccessors.fromApplication(
                applicationContext,
                FavoriteModuleDependecies::class.java
            ))
            .build()
            .inject(this)
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setAdapterAll()
        setObserverAllData()

    }

    private fun setObserverAllData(){
        favoriteViewModel.getAllFavoriteMovie().observe(this,this::setDataMovie)
        favoriteViewModel.getAllFavoriteTvShow().observe(this,this::setDataTvShow)
    }

    private fun onClickMovie(movie: Movie){
        Intent(this@FavoriteActivity,DetailActivity::class.java).apply {
            putExtra(POSITION,1)
            putExtra(EXTRA_MOVIE,movie)
        }.also { startActivity(it) }
        finish()
    }

    private fun setDataTvShow(tvShow: List<TvShow>){
        if (tvShow.isEmpty()){
            showEmptyText(true)
        }else{
            showEmptyText(false)
            tvShowAdapter.temptAllDataTvShowRecomended(tvShow)
        }
    }

    private fun setAdapterAll(){
        binding.apply {
            rvFavoriteMovie.apply {
                layoutManager = Helper.constLinearLayoutManager(this@FavoriteActivity,2)
                adapter = movieAdapter
            }
            toolbarFavorite.apply {
                title = "Candra Julius Sinaga"
                subtitle = "Favorite"
            }
            toolbarFavorite.setNavigationOnClickListener {
                onBackPressed()
            }
            binding.toolbarFavorite.setNavigationIcon(
                if (isDarkMode) com.candra.submission_one_expert.R.drawable.ic_baseline_close_24
            else com.candra.submission_one_expert.R.drawable.ic_baseline_close_black
            )
        }
    }

    private fun setDataMovie(movie: List<Movie>){
        if (movie.isEmpty()){
            showEmptyText(true)
        }else{
            showEmptyText(false)
            movieAdapter.temptAllData(movie)
        }
    }

    private fun onClickTvShow(tvShow: TvShow){
        Intent(this@FavoriteActivity,DetailActivity::class.java).apply {
            putExtra(POSITION,2)
            putExtra(EXTRA_TV,tvShow)
        }.also { startActivity(it)}
        finish()
    }

    private fun showEmptyText(isEmpty: Boolean){
        binding.mtvEmptyText.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvFavoriteMovie.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

}