package com.candra.favorite

import androidx.lifecycle.*
import com.candra.core.data.States
import com.candra.core.domain.model.Movie
import com.candra.core.domain.usecase.MovieUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

class FavoriteViewModel @Inject constructor(
    private val movieUseCase: MovieUseCase
): ViewModel()
{
    fun getAllFavoriteMovie() = movieUseCase.getAllFavoriteMovie().asLiveData()
    fun getAllFavoriteTvShow() = movieUseCase.getAllFavoriteTvShow().asLiveData()
}